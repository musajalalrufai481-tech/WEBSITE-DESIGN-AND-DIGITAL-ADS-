import express from './lib/mini.js';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { all, get, run } from './lib/db.js';
import { CATEGORIES, BUDGETS } from './lib/seed.js';
import * as sec from './lib/security.js';
import { chat, brief, aiConfigured } from './lib/ai.js';
import * as R from './lib/render.js';

const { S, isEmail, isPhone, safeUrl, rateLimit, requireAdmin } = sec;
const PUBLIC = path.join(path.dirname(fileURLToPath(import.meta.url)), 'public');
const PROD = process.env.NODE_ENV === 'production';

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', Number(process.env.TRUST_PROXY ?? 1));

// ---------- Security headers ----------
app.use((req, res, next) => {
  res.set({
    'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data: https:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'; object-src 'none'",
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=(), payment=()',
    'Cross-Origin-Opener-Policy': 'same-origin',
  });
  if (PROD) res.set('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  next();
});

app.use(express.json({ limit: '30kb' }));

// Reject cross-site writes (Origin must match Host when present).
app.use('/api', (req, res, next) => {
  if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) {
    const o = req.get('origin');
    if (o) {
      try { if (new URL(o).host !== req.get('host')) throw 0; } catch { return res.status(403).json({ ok: false, error: 'Forbidden.' }); }
    }
  }
  next();
});

app.use(express.static(PUBLIC, {
  maxAge: '30d',
  setHeaders: (res, p) => {
    if (/\.html$/.test(p)) res.set('Cache-Control', 'no-cache');
    if (p.includes(`${path.sep}admin${path.sep}`)) res.set({ 'Cache-Control': 'no-cache', 'X-Robots-Tag': 'noindex, nofollow' }); // admin assets are unversioned
  },
}));

// ---------- Helpers ----------
const render = (fn) => (req, res) => {
  const ctx = R.ctxFor(req);
  res.set('Cache-Control', 'no-cache').type('html').send(fn(ctx, req));
};
const notify = (text) => {
  const url = process.env.NOTIFY_WEBHOOK_URL;
  if (!url) return;
  // Slack/Discord/Zapier/Make compatible: sends both `text` and `content`.
  fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text, content: text }), signal: AbortSignal.timeout(8000) })
    .catch((e) => console.error('[notify] failed:', e.message));
};
const ref = (id) => `WDA-${String(id).padStart(5, '0')}`;
function spamCheck(b, res) {
  if (b.website) { res.json({ ok: true, ref: 'WDA-00000' }); return true; } // honeypot: silently accept
  const t = Number(b.t);
  if (t && Date.now() - t < 3000) { res.status(400).json({ ok: false, error: 'That was very quick. Please check your details and try again.' }); return true; }
  return false;
}

// ---------- Pages ----------
app.get('/healthz', (req, res) => res.type('text').send('ok'));
app.get('/', render(R.home));
app.get('/services', render(R.servicesIndex));
app.get('/services/:slug', (req, res, next) => {
  const s = R.services().find((x) => x.slug === req.params.slug);
  if (!s) return next();
  render((ctx) => R.servicePage(ctx, s))(req, res);
});
app.get('/work', render(R.work));
app.get('/about', render(R.about));
app.get('/ai-solutions', render(R.aiSolutions));
app.get('/estimator', render(R.estimator));
app.get('/contact', render(R.contact));
app.get('/faq', render(R.faq));
app.get('/privacy', render(R.privacy));
app.get('/terms', render(R.terms));
app.get('/admin', (req, res) => { res.set({ 'X-Robots-Tag': 'noindex, nofollow', 'Cache-Control': 'no-store' }); res.sendFile(path.join(PUBLIC, 'admin', 'index.html')); });

app.get('/robots.txt', (req, res) => {
  const { base } = R.ctxFor(req);
  res.type('text').send(`User-agent: *\nAllow: /\nDisallow: /admin\nDisallow: /api/\n\nSitemap: ${base}/sitemap.xml\n`);
});
app.get('/sitemap.xml', (req, res) => {
  const { base } = R.ctxFor(req);
  const urls = ['/', '/services', '/work', '/about', '/ai-solutions', '/estimator', '/contact', '/faq', '/privacy', '/terms', ...R.services().map((s) => `/services/${s.slug}`)];
  res.type('xml').send(`<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.map((u) => `  <url><loc>${base}${u}</loc></url>`).join('\n')}\n</urlset>`);
});

// ---------- Public API ----------
app.post('/api/enquiry', rateLimit('enq', 8, 3600e3), (req, res) => {
  const b = req.body || {};
  if (spamCheck(b, res)) return;
  const kind = ['project', 'quote', 'consultation'].includes(b.kind) ? b.kind : 'project';
  const d = {
    name: S(b.name, 100), email: S(b.email, 254).toLowerCase(), phone: S(b.phone, 30), business: S(b.business, 200),
    project: S(b.project, 3000), budget: S(b.budget, 40), preferred: S(b.preferred, 120),
    service: R.services().find((s) => s.slug === b.service)?.title || '',
  };
  const errors = {};
  if (d.name.length < 2) errors.name = 'Please enter your name.';
  if (!isEmail(d.email)) errors.email = 'Please enter a valid email address.';
  if (d.phone && !isPhone(d.phone)) errors.phone = 'Please enter a valid phone number.';
  if (d.project.length < 10) errors.project = 'Please describe your project (at least 10 characters).';
  if (kind !== 'consultation' && !BUDGETS.includes(d.budget)) errors.budget = 'Please choose a budget range.';
  if (b.consent !== true) errors.consent = 'Please accept the privacy policy to continue.';
  if (Object.keys(errors).length) return res.status(422).json({ ok: false, errors });
  const { id } = run('INSERT INTO enquiries(kind,service,business,project,budget,preferred,name,email,phone) VALUES(?,?,?,?,?,?,?,?,?)',
    kind, d.service, d.business, d.project, BUDGETS.includes(d.budget) ? d.budget : '', d.preferred, d.name, d.email, d.phone);
  notify(`New ${kind} enquiry ${ref(id)} from ${d.name} (${d.email}${d.phone ? ', ' + d.phone : ''}) - ${d.service || 'service not chosen'}, budget ${d.budget || 'n/a'}.`);
  res.json({ ok: true, ref: ref(id) });
});

app.post('/api/contact', rateLimit('contact', 8, 3600e3), (req, res) => {
  const b = req.body || {};
  if (spamCheck(b, res)) return;
  const d = { name: S(b.name, 100), email: S(b.email, 254).toLowerCase(), message: S(b.message, 2000) };
  const errors = {};
  if (d.name.length < 2) errors.name = 'Please enter your name.';
  if (!isEmail(d.email)) errors.email = 'Please enter a valid email address.';
  if (d.message.length < 10) errors.message = 'Please write a message (at least 10 characters).';
  if (b.consent !== true) errors.consent = 'Please accept the privacy policy to continue.';
  if (Object.keys(errors).length) return res.status(422).json({ ok: false, errors });
  const { id } = run('INSERT INTO contacts(name,email,message) VALUES(?,?,?)', d.name, d.email, d.message);
  notify(`New contact message from ${d.name} (${d.email}): ${d.message.slice(0, 200)}`);
  res.json({ ok: true, ref: `MSG-${String(id).padStart(5, '0')}` });
});

app.post('/api/subscribe', rateLimit('sub', 6, 3600e3), (req, res) => {
  const b = req.body || {};
  if (spamCheck(b, res)) return;
  const email = S(b.email, 254).toLowerCase();
  if (!isEmail(email)) return res.status(422).json({ ok: false, errors: { email: 'Please enter a valid email address.' } });
  run('INSERT OR IGNORE INTO subscribers(email) VALUES(?)', email);
  res.json({ ok: true });
});

app.post('/api/chat', rateLimit('chat', 20, 600e3), async (req, res) => {
  const msgs = (Array.isArray(req.body?.messages) ? req.body.messages : []).slice(-10)
    .filter((m) => m && ['user', 'assistant'].includes(m.role) && typeof m.content === 'string')
    .map((m) => ({ role: m.role, content: S(m.content, 1000) })).filter((m) => m.content);
  if (!msgs.length || msgs.at(-1).role !== 'user') return res.status(400).json({ ok: false, error: 'Please type a message.' });
  res.json({ ok: true, ...(await chat(msgs)) });
});

app.post('/api/brief', rateLimit('brief', 6, 600e3), async (req, res) => {
  const b = req.body || {};
  if (b.website) return res.json({ ok: true, brief: '', demo: true });
  const description = S(b.description, 1500);
  if (description.length < 20) return res.status(422).json({ ok: false, error: 'Please describe your project in at least 20 characters.' });
  res.json({ ok: true, ...(await brief(description, S(b.service, 120))) });
});

app.post('/api/hit', rateLimit('hit', 120, 60e3), (req, res) => {
  const p = String(req.body?.path || '');
  if (/^\/[a-z0-9\-\/]{0,100}$/i.test(p) && !p.startsWith('/admin')) {
    run('INSERT INTO pageviews(day,path,n) VALUES(?,?,1) ON CONFLICT(day,path) DO UPDATE SET n=n+1', new Date().toISOString().slice(0, 10), p);
  }
  res.status(204).end();
});

// ---------- Admin API ----------
const loginLimit = rateLimit('login', 8, 15 * 60e3);
app.post('/api/admin/login', loginLimit, (req, res) => {
  const email = S(req.body?.email, 254).toLowerCase();
  const pw = String(req.body?.password || '').slice(0, 200);
  const admin = get('SELECT * FROM admins WHERE email=?', email);
  const ok = admin ? sec.verifyPassword(pw, admin.hash) : (sec.burnTime(pw), false);
  if (!ok) return res.status(401).json({ ok: false, error: 'Incorrect email or password.' });
  sec.setSessionCookie(res, req, sec.createSession(admin.id));
  res.json({ ok: true, email: admin.email });
});
app.post('/api/admin/logout', (req, res) => { sec.destroySession(req); sec.clearSessionCookie(res); res.json({ ok: true }); });
app.get('/api/admin/me', (req, res) => {
  const s = sec.getSession(req);
  if (!s) return res.status(401).json({ ok: false });
  res.json({ ok: true, email: s.email, ai: aiConfigured(), configured: Boolean(get('SELECT 1 x FROM admins LIMIT 1')) });
});

const admin = express.Router();
admin.use(requireAdmin);
app.use('/api/admin', admin);

admin.get('/stats', (req, res) => {
  const since = "date('now','-29 day')";
  res.json({
    ok: true,
    counts: {
      enquiriesNew: get("SELECT COUNT(*) c FROM enquiries WHERE status='new'").c,
      enquiries: get('SELECT COUNT(*) c FROM enquiries').c,
      contacts: get('SELECT COUNT(*) c FROM contacts').c,
      subscribers: get('SELECT COUNT(*) c FROM subscribers').c,
      views30: get(`SELECT COALESCE(SUM(n),0) c FROM pageviews WHERE day>=${since}`).c,
    },
    daily: all(`SELECT day, SUM(n) n FROM pageviews WHERE day>=${since} GROUP BY day ORDER BY day`),
    top: all(`SELECT path, SUM(n) n FROM pageviews WHERE day>=${since} GROUP BY path ORDER BY n DESC LIMIT 8`),
    byStatus: all('SELECT status, COUNT(*) n FROM enquiries GROUP BY status'),
    ai: aiConfigured(),
  });
});

const STATUSES = ['new', 'contacted', 'quoted', 'in-progress', 'won', 'closed'];
admin.get('/enquiries', (req, res) => res.json({ ok: true, items: all('SELECT * FROM enquiries ORDER BY id DESC LIMIT 500'), statuses: STATUSES }));
admin.patch('/enquiries/:id', (req, res) => {
  const status = STATUSES.includes(req.body?.status) ? req.body.status : null;
  if (!status) return res.status(422).json({ ok: false, error: 'Invalid status.' });
  run('UPDATE enquiries SET status=?, notes=? WHERE id=?', status, S(req.body?.notes, 3000), Number(req.params.id));
  res.json({ ok: true });
});
admin.delete('/enquiries/:id', (req, res) => { run('DELETE FROM enquiries WHERE id=?', Number(req.params.id)); res.json({ ok: true }); });

admin.get('/contacts', (req, res) => res.json({ ok: true, items: all('SELECT * FROM contacts ORDER BY id DESC LIMIT 500') }));
admin.patch('/contacts/:id', (req, res) => {
  const status = ['new', 'read', 'replied'].includes(req.body?.status) ? req.body.status : null;
  if (!status) return res.status(422).json({ ok: false, error: 'Invalid status.' });
  run('UPDATE contacts SET status=? WHERE id=?', status, Number(req.params.id));
  res.json({ ok: true });
});
admin.delete('/contacts/:id', (req, res) => { run('DELETE FROM contacts WHERE id=?', Number(req.params.id)); res.json({ ok: true }); });

admin.get('/subscribers', (req, res) => res.json({ ok: true, items: all('SELECT * FROM subscribers ORDER BY id DESC') }));
admin.delete('/subscribers/:id', (req, res) => { run('DELETE FROM subscribers WHERE id=?', Number(req.params.id)); res.json({ ok: true }); });
admin.get('/subscribers.csv', (req, res) => {
  const rows = all('SELECT email, created FROM subscribers ORDER BY id');
  const safe = (v) => { const s = String(v); return /^[=+\-@]/.test(s) ? `'${s}` : s; }; // block CSV formula injection
  res.type('text/csv').set('Content-Disposition', 'attachment; filename="subscribers.csv"').send('email,subscribed\n' + rows.map((r) => `${safe(r.email)},${r.created}`).join('\n'));
});

// Projects
function projectInput(b) {
  const d = { title: S(b.title, 150), category: S(b.category, 30), description: S(b.description, 1500), tech: S(b.tech, 300), demo_url: S(b.demo_url, 500), image_url: S(b.image_url, 500), is_concept: b.is_concept ? 1 : 0, sort: parseInt(b.sort, 10) || 0, published: b.published ? 1 : 0 };
  if (!d.title) return { error: 'Title is required.' };
  if (!CATEGORIES.some(([k]) => k === d.category)) return { error: 'Choose a valid category.' };
  if (!safeUrl(d.demo_url) || !safeUrl(d.image_url)) return { error: 'URLs must start with https:// or /.' };
  return { d };
}
admin.get('/projects', (req, res) => res.json({ ok: true, items: all('SELECT * FROM projects ORDER BY sort,id'), categories: CATEGORIES }));
admin.post('/projects', (req, res) => {
  const { d, error } = projectInput(req.body || {});
  if (error) return res.status(422).json({ ok: false, error });
  const r = run('INSERT INTO projects(title,category,description,tech,demo_url,image_url,is_concept,sort,published) VALUES(?,?,?,?,?,?,?,?,?)', d.title, d.category, d.description, d.tech, d.demo_url, d.image_url, d.is_concept, d.sort, d.published);
  res.json({ ok: true, id: r.id });
});
admin.put('/projects/:id', (req, res) => {
  const { d, error } = projectInput(req.body || {});
  if (error) return res.status(422).json({ ok: false, error });
  run('UPDATE projects SET title=?,category=?,description=?,tech=?,demo_url=?,image_url=?,is_concept=?,sort=?,published=? WHERE id=?', d.title, d.category, d.description, d.tech, d.demo_url, d.image_url, d.is_concept, d.sort, d.published, Number(req.params.id));
  res.json({ ok: true });
});
admin.delete('/projects/:id', (req, res) => { run('DELETE FROM projects WHERE id=?', Number(req.params.id)); res.json({ ok: true }); });

// Services
const lines = (v) => String(v ?? '').split('\n').map((x) => S(x, 200)).filter(Boolean).slice(0, 12);
function serviceInput(b) {
  const d = { title: S(b.title, 120), short: S(b.short, 300), description: S(b.description, 2000), icon: S(b.icon, 20) || 'gem', category: S(b.category, 30), benefits: JSON.stringify(lines(b.benefits)), deliverables: JSON.stringify(lines(b.deliverables)), sort: parseInt(b.sort, 10) || 0, published: b.published ? 1 : 0 };
  if (!d.title) return { error: 'Title is required.' };
  return { d };
}
admin.get('/services', (req, res) => res.json({ ok: true, items: all('SELECT * FROM services ORDER BY sort,id').map((s) => ({ ...s, benefits: JSON.parse(s.benefits || '[]').join('\n'), deliverables: JSON.parse(s.deliverables || '[]').join('\n') })), categories: CATEGORIES }));
admin.put('/services/:id', (req, res) => {
  const { d, error } = serviceInput(req.body || {});
  if (error) return res.status(422).json({ ok: false, error });
  run('UPDATE services SET title=?,short=?,description=?,icon=?,category=?,benefits=?,deliverables=?,sort=?,published=? WHERE id=?', d.title, d.short, d.description, d.icon, d.category, d.benefits, d.deliverables, d.sort, d.published, Number(req.params.id));
  res.json({ ok: true });
});
admin.post('/services', (req, res) => {
  const { d, error } = serviceInput(req.body || {});
  if (error) return res.status(422).json({ ok: false, error });
  let slug = d.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 60) || 'service';
  if (get('SELECT 1 x FROM services WHERE slug=?', slug)) slug += '-' + Date.now().toString(36);
  const r = run('INSERT INTO services(slug,title,short,description,icon,category,benefits,deliverables,sort,published) VALUES(?,?,?,?,?,?,?,?,?,?)', slug, d.title, d.short, d.description, d.icon, d.category, d.benefits, d.deliverables, d.sort, d.published);
  res.json({ ok: true, id: r.id });
});
admin.delete('/services/:id', (req, res) => { run('DELETE FROM services WHERE id=?', Number(req.params.id)); res.json({ ok: true }); });

// Site content
admin.get('/content', (req, res) => res.json({ ok: true, content: R.content() }));
admin.put('/content', (req, res) => {
  const body = req.body || {};
  const allowed = Object.keys(R.content());
  for (const k of allowed) {
    if (!(k in body)) continue;
    let v = S(body[k], 2000);
    if (k === 'whatsapp') v = v.replace(/\D/g, '');
    if (k === 'founder_photo_url' && !safeUrl(v)) return res.status(422).json({ ok: false, error: 'Photo URL must start with https:// or /.' });
    if (k === 'email' && !isEmail(v)) return res.status(422).json({ ok: false, error: 'Invalid email address.' });
    run('INSERT INTO content(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', k, v);
  }
  res.json({ ok: true });
});

admin.post('/password', (req, res) => {
  const row = get('SELECT * FROM admins WHERE id=?', req.admin.admin_id);
  const next = String(req.body?.next || '');
  if (!sec.verifyPassword(String(req.body?.current || ''), row.hash)) return res.status(403).json({ ok: false, error: 'Current password is incorrect.' });
  if (next.length < 12) return res.status(422).json({ ok: false, error: 'New password must be at least 12 characters.' });
  run('UPDATE admins SET hash=? WHERE id=?', sec.hashPassword(next), row.id);
  run('DELETE FROM sessions WHERE admin_id=?', row.id);
  sec.clearSessionCookie(res);
  res.json({ ok: true });
});

// ---------- 404 and errors ----------
app.use((req, res) => {
  if (req.path.startsWith('/api/')) return res.status(404).json({ ok: false, error: 'Not found.' });
  res.status(404).set('Cache-Control', 'no-cache').type('html').send(R.notFound(R.ctxFor(req)));
});
app.use((err, req, res, next) => { // eslint-disable-line no-unused-vars
  const bad = err.type === 'entity.parse.failed' || err.status === 400 || err.status === 413;
  if (!bad) console.error(err);
  if (req.path.startsWith('/api/')) return res.status(bad ? 400 : 500).json({ ok: false, error: bad ? 'Invalid request.' : 'Something went wrong. Please try again.' });
  res.status(500).type('text').send('Something went wrong.');
});

// ---------- First-run admin bootstrap ----------
const { ADMIN_EMAIL, ADMIN_PASSWORD } = process.env;
if (!get('SELECT 1 x FROM admins LIMIT 1')) {
  if (ADMIN_EMAIL && ADMIN_PASSWORD && ADMIN_PASSWORD.length >= 12 && isEmail(ADMIN_EMAIL)) {
    run('INSERT INTO admins(email,hash) VALUES(?,?)', ADMIN_EMAIL.toLowerCase(), sec.hashPassword(ADMIN_PASSWORD));
    console.log(`[admin] Created administrator ${ADMIN_EMAIL}`);
  } else {
    console.warn('[admin] No administrator exists. Set ADMIN_EMAIL and ADMIN_PASSWORD (12+ chars) and restart to enable /admin.');
  }
}

const PORT = Number(process.env.PORT || 3000);
export const server = app.listen(PORT, () => console.log(`[wdda] listening on :${PORT} (${PROD ? 'production' : 'development'}, AI ${aiConfigured() ? 'live' : 'demo mode'})`));
