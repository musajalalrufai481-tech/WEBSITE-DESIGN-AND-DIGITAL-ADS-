(() => {
  'use strict';
  document.documentElement.classList.add('js');
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const WA = document.body.dataset.wa || '';
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const waLink = (t) => `https://wa.me/${WA}?text=${encodeURIComponent(t)}`;
  const store = {
    get(k) { try { return localStorage.getItem(k); } catch { return null; } },
    set(k, v) { try { localStorage.setItem(k, v); } catch { /* ignore */ } },
  };
  const sess = {
    get(k) { try { return sessionStorage.getItem(k); } catch { return null; } },
    set(k, v) { try { sessionStorage.setItem(k, v); } catch { /* ignore */ } },
    del(k) { try { sessionStorage.removeItem(k); } catch { /* ignore */ } },
  };

  // ---------- Toasts ----------
  function toast(msg, type = 'ok') {
    const el = document.createElement('div');
    el.className = `toast ${type}`;
    el.setAttribute('role', type === 'error' ? 'alert' : 'status');
    el.textContent = msg;
    $('#toasts').append(el);
    setTimeout(() => el.remove(), 6000);
  }

  // ---------- Header, nav ----------
  const header = $('.site-header');
  const onScroll = () => header.classList.toggle('scrolled', scrollY > 20);
  addEventListener('scroll', onScroll, { passive: true }); onScroll();
  const toggle = $('#nav-toggle'), nav = $('#site-nav');
  const closeNav = () => { nav.classList.remove('open'); toggle.setAttribute('aria-expanded', 'false'); };
  toggle.addEventListener('click', () => { const o = nav.classList.toggle('open'); toggle.setAttribute('aria-expanded', String(o)); });
  nav.addEventListener('click', (e) => { if (e.target.closest('a')) closeNav(); });
  addEventListener('keydown', (e) => { if (e.key === 'Escape') closeNav(); });

  // ---------- Reveal on scroll, pointer glow ----------
  if ('IntersectionObserver' in window && !reduce) {
    const io = new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } }), { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
    $$('.reveal').forEach((el) => io.observe(el));
  } else $$('.reveal').forEach((el) => el.classList.add('in'));
  document.addEventListener('pointermove', (e) => {
    const c = e.target.closest?.('.card'); if (!c) return;
    const r = c.getBoundingClientRect();
    c.style.setProperty('--mx', `${e.clientX - r.left}px`); c.style.setProperty('--my', `${e.clientY - r.top}px`);
  }, { passive: true });

  // ---------- Hero canvas: gold network ----------
  const cv = $('#hero-canvas');
  if (cv) {
    const ctx = cv.getContext('2d'); let w, h, pts = [], raf, visible = true;
    const dpr = Math.min(devicePixelRatio || 1, 2);
    const init = () => {
      w = cv.clientWidth; h = cv.clientHeight; cv.width = w * dpr; cv.height = h * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const n = Math.min(70, Math.round((w * h) / 18000));
      pts = Array.from({ length: n }, () => ({ x: Math.random() * w, y: Math.random() * h, vx: (Math.random() - .5) * .25, vy: (Math.random() - .5) * .25, r: Math.random() * 1.5 + .5 }));
    };
    const draw = () => {
      ctx.clearRect(0, 0, w, h);
      for (const p of pts) {
        if (!reduce) { p.x += p.vx; p.y += p.vy; if (p.x < 0 || p.x > w) p.vx *= -1; if (p.y < 0 || p.y > h) p.vy *= -1; }
        ctx.fillStyle = 'rgba(212,175,55,.8)'; ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, 6.283); ctx.fill();
      }
      for (let i = 0; i < pts.length; i++) for (let j = i + 1; j < pts.length; j++) {
        const dx = pts[i].x - pts[j].x, dy = pts[i].y - pts[j].y, d = dx * dx + dy * dy;
        if (d < 14400) { ctx.strokeStyle = `rgba(212,175,55,${.22 * (1 - d / 14400)})`; ctx.lineWidth = .7; ctx.beginPath(); ctx.moveTo(pts[i].x, pts[i].y); ctx.lineTo(pts[j].x, pts[j].y); ctx.stroke(); }
      }
      if (!reduce && visible) raf = requestAnimationFrame(draw);
    };
    init(); draw();
    let rt; addEventListener('resize', () => { clearTimeout(rt); rt = setTimeout(() => { init(); if (reduce) draw(); }, 200); });
    new IntersectionObserver(([e]) => { visible = e.isIntersecting; if (visible && !reduce) { cancelAnimationFrame(raf); draw(); } }).observe(cv);
  }

  // ---------- Tabs (service previews) ----------
  $$('[data-tabs]').forEach((root) => {
    const tabs = $$('[role=tab]', root), panels = $$('[role=tabpanel]', root);
    const select = (i, focus) => {
      tabs.forEach((t, k) => { t.setAttribute('aria-selected', String(k === i)); t.tabIndex = k === i ? 0 : -1; });
      panels.forEach((p, k) => { p.hidden = k !== i; });
      if (focus) tabs[i].focus();
    };
    tabs.forEach((t, i) => {
      t.addEventListener('click', () => select(i));
      t.addEventListener('keydown', (e) => {
        const k = { ArrowDown: 1, ArrowRight: 1, ArrowUp: -1, ArrowLeft: -1 }[e.key];
        if (k) { e.preventDefault(); select((i + k + tabs.length) % tabs.length, true); }
        if (e.key === 'Home') { e.preventDefault(); select(0, true); }
        if (e.key === 'End') { e.preventDefault(); select(tabs.length - 1, true); }
      });
    });
  });

  // ---------- Portfolio filter ----------
  const grid = $('#proj-grid');
  if (grid) {
    const btns = $$('[data-filter]');
    btns.forEach((b) => b.addEventListener('click', () => {
      const f = b.dataset.filter; let shown = 0;
      btns.forEach((x) => x.setAttribute('aria-pressed', String(x === b)));
      $$('.proj', grid).forEach((c) => { const show = f === 'all' || c.dataset.cat === f; c.hidden = !show; if (show) { shown++; c.classList.add('in'); } });
      $('#proj-empty').hidden = shown > 0;
    }));
  }

  // ---------- Forms ----------
  $$('input[name=t]').forEach((i) => { i.value = Date.now(); });
  function clearErrors(form) {
    $$('.err', form).forEach((e) => { e.textContent = ''; });
    $$('[aria-invalid]', form).forEach((e) => e.removeAttribute('aria-invalid'));
  }
  function showErrors(form, errors) {
    let first = null;
    for (const [k, msg] of Object.entries(errors)) {
      const slot = $(`[data-error-for="${k}"]`, form); if (slot) slot.textContent = msg;
      const input = form.elements[k]; if (input) { input.setAttribute('aria-invalid', 'true'); first ||= input; }
    }
    first?.focus();
  }
  function localValidate(form) {
    const errors = {};
    for (const el of form.elements) {
      if (!el.name || el.type === 'hidden' || el.classList.contains('hp') || el.closest('[hidden]')) continue;
      if (el.type === 'checkbox' && el.required && !el.checked) errors[el.name] = 'Please accept to continue.';
      else if (el.type !== 'checkbox' && el.type !== 'radio' && el.required && !el.value.trim()) errors[el.name] = 'This field is required.';
      else if (el.type === 'email' && el.value && !/^\S+@\S+\.\S+$/.test(el.value)) errors[el.name] = 'Please enter a valid email address.';
      else if (el.minLength > 0 && el.value && el.value.trim().length < el.minLength) errors[el.name] = `Please enter at least ${el.minLength} characters.`;
    }
    return errors;
  }
  $$('form[data-api]').forEach((form) => {
    form.addEventListener('submit', async (e) => {
      e.preventDefault(); clearErrors(form);
      const local = localValidate(form);
      if (Object.keys(local).length) { showErrors(form, local); return; }
      const data = Object.fromEntries(new FormData(form));
      const cb = form.elements.consent; if (cb) data.consent = cb.checked;
      const btn = $('[type=submit]', form), label = btn.textContent;
      btn.disabled = true; btn.classList.add('loading'); btn.textContent = 'Sending';
      try {
        const r = await fetch(form.dataset.api, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
        const j = await r.json().catch(() => ({}));
        if (r.ok && j.ok) {
          if (form.classList.contains('news')) { toast('Thank you for subscribing.'); form.reset(); $('input[name=t]', form).value = Date.now(); }
          else {
            const box = form.parentElement.querySelector('.success');
            form.hidden = true; box.hidden = false; $('[data-ref]', box).textContent = j.ref || '';
            const wa = $('[data-wa-follow]', box);
            if (wa) wa.href = waLink(`Hello, I just submitted enquiry ${j.ref}.\nService: ${data.service || 'not chosen'}\nBudget: ${data.budget || 'n/a'}\nName: ${data.name}\n\n${(data.project || '').slice(0, 600)}`);
            box.focus(); sess.del('wdda_brief');
            toast('Your request was sent successfully.');
          }
        } else if (j.errors) { showErrors(form, j.errors); toast('Please check the highlighted fields.', 'error'); }
        else toast(j.error || 'Something went wrong. Please try again or use WhatsApp.', 'error');
      } catch { toast('Network error. Please check your connection or use WhatsApp.', 'error'); }
      finally { btn.disabled = false; btn.classList.remove('loading'); btn.textContent = label; }
    });
  });

  // Enquiry form: kind switching and prefill
  const enq = $('#enquiry-form');
  if (enq) {
    const q = new URLSearchParams(location.search);
    const kindInputs = $$('input[name=kind]', enq);
    const apply = () => {
      const k = kindInputs.find((i) => i.checked)?.value;
      $('.only-consult', enq).hidden = k !== 'consultation';
      const b = enq.elements.budget; b.required = k !== 'consultation';
      $('#budget-field label .req')?.toggleAttribute('hidden', k === 'consultation');
    };
    kindInputs.forEach((i) => i.addEventListener('change', apply));
    const k = q.get('kind'); if (k) { const m = kindInputs.find((i) => i.value === k); if (m) m.checked = true; }
    const s = q.get('service'); if (s && [...enq.elements.service.options].some((o) => o.value === s)) enq.elements.service.value = s;
    const brief = sess.get('wdda_brief'); if (brief) enq.elements.project.value = brief;
    apply();
  }

  // ---------- Estimator ----------
  const est = $('#est-form');
  if (est) {
    const base = { landing: 2, business: 4, corporate: 6, ecommerce: 8, ai: 9 };
    const names = { landing: 'Landing page', business: 'Business website', corporate: 'Corporate website', ecommerce: 'E-commerce store', ai: 'AI-powered website' };
    const pts = { cms: 2, booking: 2, payments: 3, multilingual: 2, chatbot: 2, seo: 1, branding: 3, admin: 3, automation: 3 };
    const flab = Object.fromEntries($$('input[name=feat]', est).map((i) => [i.value, i.nextElementSibling.textContent.trim()]));
    let scope = '';
    const calc = () => {
      const type = est.elements.type.value, pages = +est.elements.pages.value;
      const feats = $$('input[name=feat]:checked', est).map((i) => i.value);
      $('#pages-out').textContent = pages;
      const score = base[type] + pages * 0.3 + feats.reduce((a, f) => a + pts[f], 0);
      const tier = score < 6 ? 'Focused build' : score < 11 ? 'Standard build' : score < 17 ? 'Advanced build' : 'Large-scale build';
      $('#est-tier').textContent = tier; $('#est-bar').style.width = `${Math.min(100, Math.round((score / 30) * 100))}%`;
      $('#est-note').textContent = 'Indicative complexity only. Price and timeline are confirmed in a written quotation.';
      scope = `Project type: ${names[type]}\nApproximate pages: ${pages}\nFeatures: ${feats.length ? feats.map((f) => flab[f]).join(', ') : 'None selected'}\nEstimated complexity: ${tier}`;
      $('#est-scope').textContent = scope;
      $('#est-wa').href = waLink(`Hello, I used your project estimator.\n\n${scope}\n\nI would like a quotation.`);
    };
    est.addEventListener('input', calc); calc();
    $('#est-quote').addEventListener('click', () => { sess.set('wdda_brief', `Scope from the project estimator:\n${scope}`); location.href = '/contact?kind=quote'; });
  }

  // ---------- AI brief generator ----------
  const bf = $('#brief-form');
  if (bf) {
    bf.addEventListener('submit', async (e) => {
      e.preventDefault();
      const ta = bf.elements.description;
      if (ta.value.trim().length < 20) { toast('Please describe your project in at least 20 characters.', 'error'); ta.focus(); return; }
      const btn = $('[type=submit]', bf), label = btn.textContent;
      btn.disabled = true; btn.classList.add('loading'); btn.textContent = 'Generating';
      try {
        const r = await fetch('/api/brief', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ description: ta.value, website: bf.elements.website.value }) });
        const j = await r.json();
        if (!r.ok || !j.ok) throw new Error(j.error || 'failed');
        const out = $('#brief-out'); out.hidden = false;
        const pre = $('#brief-text-out'); pre.textContent = j.brief; pre.focus();
        $('#brief-note').textContent = j.demo ? 'Template draft generated in demo mode. Connect an OpenAI key on the server for AI-written briefs.' : 'Review and edit before sending.';
        sess.set('wdda_brief', j.brief);
      } catch (err) { toast(err.message === 'failed' ? 'Could not generate the brief. Please try again.' : err.message, 'error'); }
      finally { btn.disabled = false; btn.classList.remove('loading'); btn.textContent = label; }
    });
    $('#brief-copy')?.addEventListener('click', async () => { try { await navigator.clipboard.writeText($('#brief-text-out').textContent); toast('Brief copied.'); } catch { toast('Copy failed. Select the text manually.', 'error'); } });
  }

  // ---------- AI chat assistant ----------
  const chatPanel = document.createElement('section');
  chatPanel.className = 'chat'; chatPanel.hidden = true; chatPanel.setAttribute('role', 'dialog'); chatPanel.setAttribute('aria-label', 'AI assistant');
  chatPanel.innerHTML = `<div class="chat-head"><div><b>Digital Concierge</b><small id="chat-mode"></small></div><button class="chat-x" type="button" aria-label="Close chat">&times;</button></div>
    <div class="chat-log" role="log" aria-live="polite"></div>
    <div class="quick"><button type="button">Which service do I need?</button><button type="button">I want an online store</button><button type="button">Request a quotation</button><a target="_blank" rel="noopener">WhatsApp</a></div>
    <form class="chat-form"><label class="sr" for="chat-in">Your message</label><input id="chat-in" autocomplete="off" maxlength="500" placeholder="Ask about our services"><button class="btn btn-sm" type="submit">Send</button></form>`;
  const fab = document.createElement('button');
  fab.className = 'chat-fab'; fab.type = 'button'; fab.setAttribute('aria-expanded', 'false');
  fab.innerHTML = '<svg class="ico" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg><span>Ask our AI</span>';
  document.body.append(chatPanel, fab);
  const log = $('.chat-log', chatPanel), input = $('#chat-in'), cform = $('.chat-form', chatPanel);
  $('.quick a', chatPanel).href = waLink('Hello, I have a question about your services.');
  $('#chat-mode').textContent = document.body.dataset.ai === 'live' ? 'AI assistant' : 'Demo mode: guided answers';
  let history = [];
  try { history = JSON.parse(sess.get('wdda_chat') || '[]'); } catch { history = []; }

  const LINK = /(https:\/\/wa\.me\/\d+[^\s)]*|\/(?:services(?:\/[a-z0-9-]+)?|estimator|contact|work|faq|ai-solutions|about)(?![a-z0-9-]))/g;
  function addBubble(role, text, cls = '') {
    const p = document.createElement('p'); p.className = `bubble ${role === 'user' ? 'you' : 'bot'} ${cls}`;
    text.split(LINK).forEach((part, i) => {
      if (i % 2 === 0) { p.append(part); return; }
      const m = part.match(/^(.*?)([.,;:!?]*)$/); const a = document.createElement('a');
      a.href = m[1]; a.textContent = m[1].startsWith('http') ? 'WhatsApp chat' : m[1];
      if (m[1].startsWith('http')) { a.target = '_blank'; a.rel = 'noopener'; }
      p.append(a, m[2]);
    });
    log.append(p); log.scrollTop = log.scrollHeight; return p;
  }
  function render() {
    log.textContent = '';
    addBubble('assistant', 'Welcome to Website Design and Digital Ads. I can help you choose a service, prepare a project brief or request a quotation. What are you planning to build?');
    history.forEach((m) => addBubble(m.role, m.content));
  }
  async function send(text) {
    text = text.trim(); if (!text) return;
    addBubble('user', text); history.push({ role: 'user', content: text });
    const typing = addBubble('assistant', 'Typing…', 'typing');
    input.disabled = true;
    try {
      const r = await fetch('/api/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ messages: history.slice(-10) }) });
      const j = await r.json();
      typing.remove();
      if (!r.ok || !j.ok) { addBubble('assistant', j.error || 'Sorry, something went wrong. You can reach us on WhatsApp instead.'); history.pop(); }
      else { addBubble('assistant', j.reply); history.push({ role: 'assistant', content: j.reply }); $('#chat-mode').textContent = j.demo ? 'Demo mode: guided answers' : 'AI assistant'; }
    } catch { typing.remove(); addBubble('assistant', 'I could not connect. Please try again or message us on WhatsApp.'); history.pop(); }
    history = history.slice(-20); sess.set('wdda_chat', JSON.stringify(history));
    input.disabled = false; input.focus();
  }
  const openChat = () => { chatPanel.hidden = false; fab.setAttribute('aria-expanded', 'true'); input.focus(); };
  const closeChat = () => { chatPanel.hidden = true; fab.setAttribute('aria-expanded', 'false'); fab.focus(); };
  render();
  fab.addEventListener('click', () => (chatPanel.hidden ? openChat() : closeChat()));
  $('.chat-x', chatPanel).addEventListener('click', closeChat);
  chatPanel.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeChat(); });
  $$('.quick button', chatPanel).forEach((b) => b.addEventListener('click', () => send(b.textContent)));
  cform.addEventListener('submit', (e) => { e.preventDefault(); const v = input.value; input.value = ''; send(v); });
  $$('[data-open-chat]').forEach((b) => b.addEventListener('click', openChat));

  // ---------- Privacy notice and cookie-free analytics ----------
  const consent = $('#consent');
  const choice = () => store.get('wdda_consent');
  if (!choice()) consent.hidden = false;
  $$('[data-consent]', consent).forEach((b) => b.addEventListener('click', () => {
    store.set('wdda_consent', b.dataset.consent); consent.hidden = true;
    toast(b.dataset.consent === 'essential' ? 'Anonymous page counting is switched off.' : 'Thanks. Preference saved.');
  }));
  $('#privacy-settings')?.addEventListener('click', () => { consent.hidden = false; $('button', consent).focus(); });
  if (choice() !== 'essential' && navigator.doNotTrack !== '1' && !/^\/admin/.test(location.pathname)) {
    fetch('/api/hit', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ path: location.pathname }), keepalive: true }).catch(() => {});
  }
})();
