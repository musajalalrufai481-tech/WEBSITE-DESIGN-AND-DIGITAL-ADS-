(() => {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const app = $('#app');
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const toast = (m, t = '') => { const e = document.createElement('div'); e.className = `toast ${t}`; e.textContent = m; $('#toasts').append(e); setTimeout(() => e.remove(), 4500); };

  async function api(path, method = 'GET', body) {
    const r = await fetch(`/api/admin${path}`, { method, headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'wdda' }, body: body ? JSON.stringify(body) : undefined });
    const j = await r.json().catch(() => ({}));
    if (r.status === 401 && path !== '/login') { me = null; showLogin(); throw new Error('Signed out'); }
    if (!r.ok || j.ok === false) throw new Error(j.error || 'Request failed');
    return j;
  }
  const guard = (fn) => async (...a) => { try { await fn(...a); } catch (e) { if (e.message !== 'Signed out') toast(e.message, 'error'); } };

  let me = null, view = 'overview';

  function showLogin(msg = '') {
    app.innerHTML = `<form class="login" id="lf"><h1>Administrator sign in</h1><p class="muted">Website Design and Digital Ads</p>
      <label for="em">Email</label><input id="em" type="email" autocomplete="username" required>
      <label for="pw">Password</label><input id="pw" type="password" autocomplete="current-password" required>
      <p class="err" id="le">${esc(msg)}</p><div class="row"><button class="btn" type="submit">Sign in</button></div></form>`;
    $('#lf').addEventListener('submit', async (e) => {
      e.preventDefault();
      try { await api('/login', 'POST', { email: $('#em').value, password: $('#pw').value }); await boot(); }
      catch (err) { $('#le').textContent = err.message; }
    });
  }

  const NAV = [['overview', 'Overview'], ['enquiries', 'Enquiries'], ['contacts', 'Messages'], ['subscribers', 'Subscribers'], ['projects', 'Portfolio'], ['services', 'Services'], ['content', 'Site content'], ['account', 'Account']];
  function shell() {
    app.innerHTML = `<div class="shell"><aside class="side"><div class="logo">Admin</div>${NAV.map(([k, l]) => `<button class="nav" data-v="${k}" aria-current="${k === view}">${l}</button>`).join('')}<div class="spacer"></div><div class="who">${esc(me.email)}</div><button class="nav" id="out">Sign out</button><a class="muted" href="/" target="_blank">View site</a></aside><main id="main" tabindex="-1"></main></div>`;
    app.querySelectorAll('[data-v]').forEach((b) => b.addEventListener('click', () => { view = b.dataset.v; shell(); load(); }));
    $('#out').addEventListener('click', guard(async () => { await api('/logout', 'POST'); me = null; showLogin(); }));
  }
  const main = () => $('#main');
  const load = guard(async () => { main().innerHTML = '<p class="loading">Loading</p>'; await views[view](); });

  const views = {
    async overview() {
      const s = await api('/stats');
      const max = Math.max(1, ...s.daily.map((d) => d.n));
      main().innerHTML = `<h1>Overview</h1>
        <div class="cards"><div class="stat"><b>${s.counts.enquiriesNew}</b><span>New enquiries</span></div><div class="stat"><b>${s.counts.enquiries}</b><span>Total enquiries</span></div><div class="stat"><b>${s.counts.contacts}</b><span>Messages</span></div><div class="stat"><b>${s.counts.subscribers}</b><span>Subscribers</span></div><div class="stat"><b>${s.counts.views30}</b><span>Page views (30 days)</span></div></div>
        <div class="box"><h2>Page views, last 30 days</h2>${s.daily.length ? `<div class="bars" role="img" aria-label="Daily page views">${s.daily.map((d) => `<i title="${esc(d.day)}: ${d.n}" style="height:${Math.round((d.n / max) * 100)}%"></i>`).join('')}</div>` : '<p class="muted">No visits recorded yet.</p>'}
        <p class="muted">Anonymous counts only: no IP addresses or cookies. Visitors who opt out are not counted.</p></div>
        <div class="cols"><div class="box"><h2>Top pages</h2><table>${s.top.map((t) => `<tr><td>${esc(t.path)}</td><td>${t.n}</td></tr>`).join('') || '<tr><td class="muted">No data</td></tr>'}</table></div>
        <div class="box"><h2>Enquiries by status</h2><table>${s.byStatus.map((t) => `<tr><td>${esc(t.status)}</td><td>${t.n}</td></tr>`).join('') || '<tr><td class="muted">No enquiries yet</td></tr>'}</table>
        <p class="${s.ai ? '' : 'muted'}">AI assistant: <b>${s.ai ? 'connected' : 'demo mode (no OPENAI_API_KEY)'}</b></p></div></div>`;
    },
    async enquiries() {
      const { items, statuses } = await api('/enquiries');
      main().innerHTML = `<h1>Enquiries</h1>${items.length ? '' : '<p class="muted">No enquiries yet.</p>'}` + items.map((e) => `
        <details class="item" data-id="${e.id}"><summary><span class="pill ${e.status === 'new' ? 'new' : ''}">${esc(e.status)}</span><b>WDA-${String(e.id).padStart(5, '0')}</b><span>${esc(e.name)}</span><span class="muted">${esc(e.kind)} &middot; ${esc(e.service || 'no service')} &middot; ${esc(e.created)}</span></summary>
        <div class="body"><p><a href="mailto:${esc(e.email)}">${esc(e.email)}</a>${e.phone ? ` &middot; <a href="https://wa.me/${esc(e.phone.replace(/\D/g, ''))}" target="_blank" rel="noopener">${esc(e.phone)}</a>` : ''}${e.business ? ` &middot; ${esc(e.business)}` : ''}</p>
        <p class="muted">Budget: ${esc(e.budget || 'n/a')}${e.preferred ? ` &middot; Preferred time: ${esc(e.preferred)}` : ''}</p><pre class="txt">${esc(e.project)}</pre>
        <label>Status</label><select data-f="status">${statuses.map((s) => `<option${s === e.status ? ' selected' : ''}>${s}</option>`).join('')}</select>
        <label>Private notes</label><textarea data-f="notes">${esc(e.notes)}</textarea>
        <div class="row"><button class="btn" data-save>Save</button><button class="btn danger" data-del>Delete</button></div></div></details>`).join('');
      main().querySelectorAll('details.item').forEach((d) => {
        $('[data-save]', d).addEventListener('click', guard(async () => { await api(`/enquiries/${d.dataset.id}`, 'PATCH', { status: $('[data-f=status]', d).value, notes: $('[data-f=notes]', d).value }); toast('Saved'); }));
        $('[data-del]', d).addEventListener('click', guard(async () => { if (confirm('Delete this enquiry permanently?')) { await api(`/enquiries/${d.dataset.id}`, 'DELETE'); d.remove(); } }));
      });
    },
    async contacts() {
      const { items } = await api('/contacts');
      main().innerHTML = `<h1>Messages</h1>${items.length ? '' : '<p class="muted">No messages yet.</p>'}` + items.map((c) => `<details class="item" data-id="${c.id}"><summary><span class="pill ${c.status === 'new' ? 'new' : ''}">${esc(c.status)}</span><b>${esc(c.name)}</b><span class="muted">${esc(c.created)}</span></summary><div class="body"><p><a href="mailto:${esc(c.email)}">${esc(c.email)}</a></p><pre class="txt">${esc(c.message)}</pre><div class="row"><select data-f="status">${['new', 'read', 'replied'].map((s) => `<option${s === c.status ? ' selected' : ''}>${s}</option>`).join('')}</select><button class="btn" data-save>Save</button><button class="btn danger" data-del>Delete</button></div></div></details>`).join('');
      main().querySelectorAll('details.item').forEach((d) => {
        $('[data-save]', d).addEventListener('click', guard(async () => { await api(`/contacts/${d.dataset.id}`, 'PATCH', { status: $('[data-f=status]', d).value }); toast('Saved'); }));
        $('[data-del]', d).addEventListener('click', guard(async () => { if (confirm('Delete this message?')) { await api(`/contacts/${d.dataset.id}`, 'DELETE'); d.remove(); } }));
      });
    },
    async subscribers() {
      const { items } = await api('/subscribers');
      main().innerHTML = `<h1>Newsletter subscribers (${items.length})</h1><p><a class="btn ghost" href="/api/admin/subscribers.csv">Download CSV</a></p><div class="box"><table>${items.map((s) => `<tr><td>${esc(s.email)}</td><td class="muted">${esc(s.created)}</td><td><button class="btn danger" data-id="${s.id}">Remove</button></td></tr>`).join('') || '<tr><td class="muted">No subscribers yet</td></tr>'}</table></div>`;
      main().querySelectorAll('button[data-id]').forEach((b) => b.addEventListener('click', guard(async () => { if (confirm('Remove subscriber?')) { await api(`/subscribers/${b.dataset.id}`, 'DELETE'); load(); } })));
    },
    async projects() {
      const { items, categories } = await api('/projects');
      const opt = (v) => categories.map(([k, l]) => `<option value="${k}"${k === v ? ' selected' : ''}>${esc(l)}</option>`).join('');
      const form = (p = {}) => `<div class="cols"><div><label>Title</label><input data-f="title" value="${esc(p.title)}" maxlength="150"></div><div><label>Category</label><select data-f="category">${opt(p.category)}</select></div></div>
        <label>Description</label><textarea data-f="description">${esc(p.description)}</textarea>
        <label>Technology used (comma separated)</label><input data-f="tech" value="${esc(p.tech)}">
        <div class="cols"><div><label>Live demo URL (https://...)</label><input data-f="demo_url" value="${esc(p.demo_url)}"></div><div><label>Image URL (https://... or /path)</label><input data-f="image_url" value="${esc(p.image_url)}"></div></div>
        <div class="row"><label><input type="checkbox" data-f="is_concept"${p.is_concept === 0 ? '' : ' checked'}> Label as concept (untick only for real client work you have permission to show)</label><label><input type="checkbox" data-f="published"${p.published === 0 ? '' : ' checked'}> Published</label><label>Order <input data-f="sort" type="number" value="${p.sort ?? 99}" style="width:80px"></label></div>`;
      const read = (root) => { const o = {}; root.querySelectorAll('[data-f]').forEach((el) => { o[el.dataset.f] = el.type === 'checkbox' ? el.checked : el.value; }); return o; };
      main().innerHTML = `<h1>Portfolio</h1><details class="item"><summary><b>+ Add project</b></summary><div class="body" id="newp">${form()}<div class="row"><button class="btn" id="addp">Add project</button></div></div></details>` +
        items.map((p) => `<details class="item" data-id="${p.id}"><summary><span class="pill">${p.published ? 'live' : 'hidden'}</span><b>${esc(p.title)}</b><span class="muted">${esc(p.category)}${p.is_concept ? ' &middot; concept' : ''}</span></summary><div class="body">${form(p)}<div class="row"><button class="btn" data-save>Save</button><button class="btn danger" data-del>Delete</button></div></div></details>`).join('');
      $('#addp').addEventListener('click', guard(async () => { await api('/projects', 'POST', read($('#newp'))); toast('Project added'); load(); }));
      main().querySelectorAll('details.item[data-id]').forEach((d) => {
        $('[data-save]', d).addEventListener('click', guard(async () => { await api(`/projects/${d.dataset.id}`, 'PUT', read(d)); toast('Saved'); }));
        $('[data-del]', d).addEventListener('click', guard(async () => { if (confirm('Delete this project?')) { await api(`/projects/${d.dataset.id}`, 'DELETE'); d.remove(); } }));
      });
    },
    async services() {
      const { items, categories } = await api('/services');
      const opt = (v) => categories.map(([k, l]) => `<option value="${k}"${k === v ? ' selected' : ''}>${esc(l)}</option>`).join('');
      const form = (s = {}) => `<label>Title</label><input data-f="title" value="${esc(s.title)}"><label>Short description</label><input data-f="short" value="${esc(s.short)}">
        <label>Full description</label><textarea data-f="description">${esc(s.description)}</textarea>
        <div class="cols"><div><label>Benefits (one per line)</label><textarea data-f="benefits">${esc(s.benefits)}</textarea></div><div><label>What you receive (one per line)</label><textarea data-f="deliverables">${esc(s.deliverables)}</textarea></div></div>
        <div class="cols"><div><label>Related portfolio category</label><select data-f="category">${opt(s.category)}</select></div><div><label>Icon name</label><input data-f="icon" value="${esc(s.icon || 'gem')}"></div></div>
        <div class="row"><label><input type="checkbox" data-f="published"${s.published === 0 ? '' : ' checked'}> Published</label><label>Order <input data-f="sort" type="number" value="${s.sort ?? 99}" style="width:80px"></label></div>`;
      const read = (root) => { const o = {}; root.querySelectorAll('[data-f]').forEach((el) => { o[el.dataset.f] = el.type === 'checkbox' ? el.checked : el.value; }); return o; };
      main().innerHTML = `<h1>Services</h1><p class="muted">Changes appear on the website immediately. Icons: design, code, building, cart, layout, cpu, chat, workflow, megaphone, share, palette, gem, shield, search.</p><details class="item"><summary><b>+ Add service</b></summary><div class="body" id="news">${form()}<div class="row"><button class="btn" id="adds">Add service</button></div></div></details>` +
        items.map((s) => `<details class="item" data-id="${s.id}"><summary><span class="pill">${s.published ? 'live' : 'hidden'}</span><b>${esc(s.title)}</b><span class="muted">/services/${esc(s.slug)}</span></summary><div class="body">${form(s)}<div class="row"><button class="btn" data-save>Save</button><button class="btn danger" data-del>Delete</button></div></div></details>`).join('');
      $('#adds').addEventListener('click', guard(async () => { await api('/services', 'POST', read($('#news'))); toast('Service added'); load(); }));
      main().querySelectorAll('details.item[data-id]').forEach((d) => {
        $('[data-save]', d).addEventListener('click', guard(async () => { await api(`/services/${d.dataset.id}`, 'PUT', read(d)); toast('Saved'); }));
        $('[data-del]', d).addEventListener('click', guard(async () => { if (confirm('Delete this service page?')) { await api(`/services/${d.dataset.id}`, 'DELETE'); d.remove(); } }));
      });
    },
    async content() {
      const { content } = await api('/content');
      const labels = { hero_kicker: 'Hero small heading', hero_title_1: 'Hero headline, line 1', hero_title_2: 'Hero headline, line 2 (gold)', hero_sub: 'Hero supporting text', whatsapp: 'WhatsApp number (digits only, with country code)', email: 'Contact email', about_purpose: 'About: purpose', about_philosophy: 'About: philosophy', about_mission: 'About: mission', about_vision: 'About: vision', founder_name: 'Founder name', founder_title: 'Founder title', founder_bio: 'Founder biography', founder_photo_url: 'Founder photo URL (https://... or /path)' };
      main().innerHTML = `<h1>Site content</h1><div class="box">${Object.keys(content).map((k) => `<label for="c-${k}">${esc(labels[k] || k)}</label>${content[k].length > 80 || k.startsWith('about') || k.includes('bio') ? `<textarea id="c-${k}" data-k="${k}">${esc(content[k])}</textarea>` : `<input id="c-${k}" data-k="${k}" value="${esc(content[k])}">`}`).join('')}<div class="row"><button class="btn" id="savec">Save changes</button></div></div>`;
      $('#savec').addEventListener('click', guard(async () => { const o = {}; main().querySelectorAll('[data-k]').forEach((el) => { o[el.dataset.k] = el.value; }); await api('/content', 'PUT', o); toast('Content saved'); }));
    },
    async account() {
      main().innerHTML = `<h1>Account</h1><div class="box" style="max-width:420px"><h2>Change password</h2><label for="cp">Current password</label><input id="cp" type="password" autocomplete="current-password"><label for="np">New password (12+ characters)</label><input id="np" type="password" autocomplete="new-password"><p class="err" id="pe"></p><div class="row"><button class="btn" id="chg">Change password</button></div></div>`;
      $('#chg').addEventListener('click', async () => {
        try { await api('/password', 'POST', { current: $('#cp').value, next: $('#np').value }); toast('Password changed. Please sign in again.'); me = null; showLogin(); }
        catch (e) { $('#pe').textContent = e.message; }
      });
    },
  };

  async function boot() {
    try { me = await (await fetch('/api/admin/me')).json(); } catch { me = null; }
    if (!me?.ok) { me = null; return showLogin(); }
    shell(); load();
  }
  boot();
})();
