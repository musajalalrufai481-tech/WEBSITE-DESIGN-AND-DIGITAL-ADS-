// End-to-end smoke test. Boots the server on a temp database and exercises pages, APIs, admin auth and security controls.
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const PORT = 3999;
const BASE = `http://127.0.0.1:${PORT}`;
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'wdda-'));
const ADMIN = { email: 'admin@example.com', password: 'a-very-long-test-password' };
const srv = spawn('node', ['server.js'], { env: { ...process.env, PORT, DATA_DIR: dir, ADMIN_EMAIL: ADMIN.email, ADMIN_PASSWORD: ADMIN.password, OPENAI_API_KEY: '', SITE_URL: 'https://example.com' }, stdio: ['ignore', 'pipe', 'pipe'] });
let log = ''; srv.stdout.on('data', (d) => (log += d)); srv.stderr.on('data', (d) => (log += d));

let pass = 0, fail = 0;
const ok = (c, name) => { c ? pass++ : fail++; console.log(`${c ? 'PASS' : 'FAIL'}  ${name}`); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const post = (p, body, headers = {}) => fetch(BASE + p, { method: 'POST', headers: { 'Content-Type': 'application/json', ...headers }, body: JSON.stringify(body) });

try {
  for (let i = 0; i < 50; i++) { try { if ((await fetch(BASE + '/healthz')).ok) break; } catch { /* wait */ } await sleep(200); }

  // Pages
  const pages = ['/', '/services', '/work', '/about', '/ai-solutions', '/estimator', '/contact', '/faq', '/privacy', '/terms'];
  for (const p of pages) { const r = await fetch(BASE + p); const t = await r.text(); ok(r.status === 200 && t.includes('</html>') && /<h1/.test(t), `GET ${p} renders`); }
  const home = await (await fetch(BASE + '/')).text();
  ok(home.includes("We don’t just build websites."), 'home has required headline');
  ok(/Concept/.test(await (await fetch(BASE + '/work')).text()), 'portfolio labels concepts');
  ok(!/sk-[A-Za-z0-9]{20,}/.test(home), 'no secret keys in HTML');
  const svc = await fetch(BASE + '/services/ai-chatbot-integration'); ok(svc.status === 200, 'service detail page');
  const slugs = [...(await (await fetch(BASE + '/sitemap.xml')).text()).matchAll(/\/services\/([a-z0-9-]+)</g)].map((m) => m[1]);
  ok(slugs.length === 14, `sitemap lists 14 service pages (got ${slugs.length})`);
  for (const s of slugs) { const r = await fetch(`${BASE}/services/${s}`); if (r.status !== 200) ok(false, `service ${s}`); }
  const nf = await fetch(BASE + '/nope'); ok(nf.status === 404 && (await nf.text()).includes('doesn&rsquo;t exist'), 'custom 404 page');
  ok((await (await fetch(BASE + '/robots.txt')).text()).includes('Sitemap: https://example.com/sitemap.xml'), 'robots.txt');
  const h = (await fetch(BASE + '/')).headers; ok(h.get('content-security-policy')?.includes("script-src 'self'") && h.get('x-frame-options') === 'DENY', 'security headers');

  // Enquiry
  const good = { kind: 'quote', service: 'ecommerce-development', business: 'Test Co', project: 'I need an online store for my shop.', budget: '$500 – $1,500', name: 'Ada Test', email: 'ada@example.com', phone: '+2348012345678', consent: true, t: Date.now() - 10000 };
  let r = await post('/api/enquiry', good); let j = await r.json(); ok(r.status === 200 && /^WDA-\d{5}$/.test(j.ref), `enquiry accepted (${j.ref})`);
  r = await post('/api/enquiry', { ...good, email: 'bad', name: '', consent: false }); j = await r.json(); ok(r.status === 422 && j.errors.email && j.errors.name && j.errors.consent, 'enquiry validation errors');
  r = await post('/api/enquiry', { ...good, website: 'http://spam' }); j = await r.json(); ok(j.ref === 'WDA-00000', 'honeypot silently dropped');
  r = await post('/api/enquiry', { ...good, t: Date.now() }); ok(r.status === 400, 'too-fast submission rejected');
  r = await post('/api/enquiry', good, { Origin: 'https://evil.example' }); ok(r.status === 403, 'cross-origin write rejected');
  r = await post('/api/contact', { name: 'Bo', email: 'bo@example.com', message: 'Hello there, I have a question.', consent: true, t: Date.now() - 9000 }); ok(r.status === 200, 'contact message accepted');
  r = await post('/api/subscribe', { email: 'news@example.com', t: Date.now() - 9000 }); ok(r.status === 200, 'newsletter subscribe');

  // AI demo mode
  r = await post('/api/chat', { messages: [{ role: 'user', content: 'How much does an online store cost?' }] }); j = await r.json(); ok(j.ok && j.demo === true && /\/estimator/.test(j.reply), 'chat demo reply');
  r = await post('/api/chat', { messages: [] }); ok(r.status === 400, 'chat rejects empty');
  r = await post('/api/brief', { description: 'I run a catering business and need a booking website.' }); j = await r.json(); ok(j.ok && j.brief.includes('Overview'), 'brief generator (demo)');

  // Analytics
  r = await post('/api/hit', { path: '/services' }); ok(r.status === 204, 'page-view beacon');

  // Admin security
  r = await fetch(BASE + '/api/admin/enquiries'); ok(r.status === 401, 'admin API requires login');
  r = await post('/api/admin/login', { email: ADMIN.email, password: 'wrong-password' }); ok(r.status === 401, 'wrong password rejected');
  r = await post('/api/admin/login', ADMIN); ok(r.status === 200, 'admin login');
  const cookie = r.headers.get('set-cookie'); ok(/HttpOnly/.test(cookie) && /SameSite=Strict/.test(cookie), 'session cookie is HttpOnly + SameSite=Strict');
  const ck = cookie.split(';')[0];
  const A = (p, m = 'GET', b) => fetch(BASE + '/api/admin' + p, { method: m, headers: { 'Content-Type': 'application/json', Cookie: ck, 'X-Requested-With': 'wdda' }, body: b ? JSON.stringify(b) : undefined });
  r = await post('/api/admin/projects', { title: 'x', category: 'ai' }, { Cookie: ck }); ok(r.status === 403, 'admin write without CSRF header rejected');
  j = await (await A('/enquiries')).json(); ok(j.items.length === 1 && j.items[0].service === 'E-commerce Development', 'admin sees the enquiry');
  r = await A(`/enquiries/${j.items[0].id}`, 'PATCH', { status: 'contacted', notes: 'Called' }); ok(r.status === 200, 'admin updates enquiry status');
  j = await (await A('/stats')).json(); ok(j.counts.enquiries === 1 && j.counts.views30 >= 1 && j.counts.subscribers === 1, 'admin stats');
  r = await A('/projects', 'POST', { title: 'Real Project <b>', category: 'business', description: 'd', tech: 'HTML', demo_url: 'javascript:alert(1)', published: true }); ok(r.status === 422, 'admin rejects javascript: URL');
  r = await A('/projects', 'POST', { title: 'Admin Added <script>', category: 'business', description: 'd', tech: 'HTML', demo_url: 'https://example.com', is_concept: true, published: true }); ok(r.status === 200, 'admin adds project');
  const work = await (await fetch(BASE + '/work')).text(); ok(work.includes('Admin Added &lt;script&gt;') && !work.includes('<script>alert'), 'project output is HTML-escaped');
  r = await A('/content', 'PUT', { hero_title_1: 'Edited headline' }); ok(r.status === 200 && (await (await fetch(BASE + '/')).text()).includes('Edited headline'), 'admin edits site content');
  r = await A('/services/1', 'PUT', { title: 'Premium Website Design', short: 's', description: 'Edited service text', benefits: 'a\nb', deliverables: 'c', category: 'business', published: true, sort: 1 }); ok(r.status === 200 && (await (await fetch(BASE + '/services/premium-website-design')).text()).includes('Edited service text'), 'admin edits service');
  r = await A('/subscribers.csv'); ok(r.status === 200 && (await r.text()).includes('news@example.com'), 'subscribers CSV export');
  r = await A('/logout', 'POST'); r = await fetch(BASE + '/api/admin/enquiries', { headers: { Cookie: ck } }); ok(r.status === 401, 'logout invalidates session');

  // Brute force limit (8 per 15 min; several already used)
  let limited = false; for (let i = 0; i < 10; i++) { r = await post('/api/admin/login', { email: ADMIN.email, password: 'nope' + i }); if (r.status === 429) limited = true; } ok(limited, 'login rate limiting');
} catch (e) { fail++; console.error('ERROR', e); }

srv.kill(); fs.rmSync(dir, { recursive: true, force: true });
console.log(`\n${pass} passed, ${fail} failed`);
if (fail) { console.log('\nServer log:\n' + log); process.exit(1); }
