# Website Design and Digital Ads: luxury agency website

A complete, working website with a secure backend, AI assistant, project enquiry system and private admin dashboard.

**Zero npm dependencies.** It runs on Node.js 22.5+ alone (built-in HTTP server and SQLite). There is nothing to `npm install`.

## What is in the box

| Area | What it does |
|---|---|
| Public site | Home, Services (14 detail pages), Our Work (filterable concept portfolio), About (founder section), AI Solutions, Project Estimator, Contact, FAQ, Privacy, Terms, custom 404 |
| Conversion | Project request, quotation request and consultation booking form; quick message form; newsletter; WhatsApp floating button and prefilled messages; email links |
| AI | Floating assistant + AI project-brief generator, via a **server-side** OpenAI proxy. Runs in demo mode without a key |
| Admin (`/admin`) | Real login (scrypt password hashing, HttpOnly session cookie, CSRF protection, login rate limiting). Manage enquiries, messages, subscribers (CSV export), portfolio, services, site text, analytics, password |
| SEO | Titles, meta descriptions, canonical URLs, Open Graph, `sitemap.xml`, `robots.txt`, JSON-LD (business, services, FAQ, breadcrumbs), semantic HTML |
| Security | CSP, HSTS, clickjacking protection, origin checks, honeypot + time-trap + rate limits on every public form, HTML escaping everywhere, no secrets in the browser |

## Honesty rules built in

- Portfolio items are labelled **Concept**. No invented clients, testimonials, awards or statistics exist anywhere.
- The estimator shows **complexity, not prices**. The assistant is instructed never to invent prices or timelines.
- The founder section is a placeholder until you add a real photo and biography.

## Run it locally

```bash
cd wdda
cp .env.example .env        # optional, then export the variables, or run inline:
ADMIN_EMAIL=you@example.com ADMIN_PASSWORD='a-long-unique-password' node server.js
```
Open http://localhost:3000 and http://localhost:3000/admin.

Run the automated tests (boots a temporary server and checks 45 behaviours):
```bash
npm test
```

## Environment variables

| Variable | Required | Purpose |
|---|---|---|
| `SITE_URL` | Yes (production) | Public address, e.g. `https://www.yourdomain.com`, used for canonical links, sitemap and social previews |
| `ADMIN_EMAIL`, `ADMIN_PASSWORD` | Yes (first start) | Creates the first administrator (password 12+ chars). Change it later in Admin > Account |
| `DATA_DIR` | Yes (production) | Folder for the SQLite database. **Must be on persistent storage** |
| `OPENAI_API_KEY` | Optional | Turns the assistant and brief generator from demo mode to live AI |
| `OPENAI_MODEL` | Optional | Defaults to `gpt-4o-mini` |
| `NOTIFY_WEBHOOK_URL` | Optional | Slack/Discord/Zapier/Make URL. You get an instant message for every new enquiry |
| `TRUST_PROXY` | Optional | Proxies in front of the app (default `1`, correct for Render, Railway, Fly) |
| `PORT` | Optional | Default 3000 (hosts set this automatically) |

> **Credentials you must supply:** an OpenAI API key (for live AI) and, if you want phone alerts, a webhook URL. There is no email-sending (SMTP) service wired in. Enquiries are stored in the dashboard, and the webhook notifies you. Nothing pretends to work without these.

## Deploy to the cloud

The app stores data in a SQLite file, so the host **must provide a persistent disk/volume**. Free tiers that wipe the disk on each deploy will lose your enquiries.

### Option A: Render (simple; paid instance needed for a disk)
1. Push this folder to a GitHub repository (the `.gitignore` already excludes `data/` and `.env`).
2. Render dashboard > **New > Blueprint** > select the repo. `render.yaml` configures everything, including a 1 GB disk at `/var/data`.
3. Fill in `SITE_URL`, `ADMIN_EMAIL`, `ADMIN_PASSWORD` (and optionally `OPENAI_API_KEY`, `NOTIFY_WEBHOOK_URL`) when prompted.
4. Deploy. Open `https://<your-service>.onrender.com/admin`.

### Option B: Railway
1. New project > Deploy from GitHub repo (it detects the `Dockerfile`).
2. Add a **Volume** mounted at `/var/data`.
3. Set the variables above (`DATA_DIR=/var/data`).

### Option C: Fly.io, VPS or any Docker host
```bash
docker build -t wdda .
docker run -d -p 3000:3000 -v wdda-data:/var/data \
  -e SITE_URL=https://www.yourdomain.com -e ADMIN_EMAIL=you@example.com \
  -e ADMIN_PASSWORD='a-long-unique-password' -e OPENAI_API_KEY=sk-... wdda
```
Put Caddy or Nginx in front for HTTPS (Caddy does it automatically: `yourdomain.com { reverse_proxy localhost:3000 }`).

## Connect your domain
1. In your host's dashboard, add the custom domain (`www.yourdomain.com` and the root domain).
2. At your domain registrar, create the DNS records the host shows: normally a `CNAME` for `www` pointing to the host's address, and an `A`/`ALIAS` record for the root.
3. Wait for DNS (minutes to a few hours). HTTPS certificates are issued automatically.
4. Set `SITE_URL` to the final `https://` address and redeploy so the sitemap and social previews use it.
5. Submit `https://yourdomain.com/sitemap.xml` in Google Search Console.

## After launch checklist
- [ ] Sign in at `/admin`, change the password, then **Site content**: add the founder's name, biography and photo URL.
- [ ] Add a real WhatsApp/email if different (Site content tab). Contact links update everywhere.
- [ ] Replace concept projects with real client work (**Portfolio** tab). Untick "Label as concept" only for work you have permission to show, and add an image URL and live link.
- [ ] Have the **Privacy Policy** and **Terms** reviewed by a qualified legal professional for your country. They are sensible starting templates, not legal advice.
- [ ] Back up the `DATA_DIR` folder regularly (it contains all enquiries).
- [ ] Add your OpenAI key and set a spending limit in your OpenAI account.

## Testing checklist
- `npm test` passes.
- Submit the enquiry form on `/contact`, then see it in `/admin > Enquiries`.
- Open the chat, ask "how much does a store cost?", and confirm the reply links work.
- Check mobile layout in your browser's device mode, and run Lighthouse in Chrome DevTools.

## Project structure
```
server.js           routes, security headers, public + admin APIs
lib/mini.js         dependency-free web framework (router, static files, gzip, JSON body)
lib/db.js           SQLite schema + seeding (node:sqlite)
lib/security.js     password hashing, sessions, rate limiting, validation
lib/ai.js           server-side OpenAI proxy + demo fallback
lib/render.js       server-rendered pages (SEO-friendly HTML)
lib/visuals.js      original SVG artwork and icon set
lib/seed.js         default services, portfolio concepts and site text
public/css, js      design system and interactions
public/admin        private dashboard
test/smoke.js       end-to-end tests
Dockerfile, render.yaml, .env.example
```

## Notes and limits
- Fonts load from Google Fonts. If the font service is unreachable the site falls back to system serif/sans fonts.
- Rate limits are kept in memory, so run a single instance (the default), or add a shared store if you scale out.
- Page views are cookie-free, anonymous counts (path + date only).
